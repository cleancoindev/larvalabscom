java -cp . LauncherBootstrap -executablename starfish-0.8 starfish $*
