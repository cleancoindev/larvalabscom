./starfish.sh $1 "-start=com.larvalabs.starfish.examples.SleepAlgorithm" starfish-examples.jar sleepproblem max.delay.seconds=30 num.segments=10
